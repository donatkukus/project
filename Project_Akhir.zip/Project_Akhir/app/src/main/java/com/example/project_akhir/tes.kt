package com.example.project_akhir

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class tes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tes)
    }
}