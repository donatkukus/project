package com.example.project_akhir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button

class login : AppCompatActivity(){
    lateinit var name_list: ArrayList<String>
    lateinit var password_list: ArrayList<String>
    private lateinit var buat_akun: Button
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        buat_akun = findViewById(R.id.btn_buatAkun)
        btnLogin = findViewById(R.id.btn_masuk)
        buat_akun.setOnClickListener(){
            intent =  Intent(this,register::class.java)
            startActivity(intent)
        }
        btnLogin.setOnClickListener(){
            intent = getIntent()
            
        }
    }


}