package com.example.project_akhir


data class Gunung(
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0
)
