package com.example.project_akhir

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class search_main : AppCompatActivity() {
    private lateinit var rvGunung: RecyclerView
    private var list: ArrayList<Gunung> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_main)

        rvGunung = findViewById(R.id.rv_gunung)
        rvGunung.setHasFixedSize(true)

        list.addAll(dataGunung.listData)
        showRecyclerCardView()
    }
    private fun showRecyclerCardView(){
        rvGunung.layoutManager = LinearLayoutManager(this)
        val cardViewHeroAdapter = CardViewGunungAdapter(list)
        rvGunung.adapter = cardViewHeroAdapter
    }
}