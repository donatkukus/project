package com.example.project_akhir

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class reservasi_main : AppCompatActivity() {
    lateinit var imgBtn:  ImageButton
    lateinit var profileBtn : ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reservasi_main)
    }
}