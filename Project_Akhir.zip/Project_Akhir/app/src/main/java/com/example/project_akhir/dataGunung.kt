package com.example.project_akhir

object dataGunung {
    private val namaGunung = arrayOf("Anjasmoro",
        "Arjuno",
        "Butak",
        "Panderman",
        "Semeru",
        "Welirang")

    private val detailGunung = arrayOf("Gunung Anjasmoro berada di Kota Batu, berada di ketinggian 2.277 mdpl.",
        "Gunung Arjuno merupakan gunung  dengan ketinggian 3.339 mdpl ",
        "Gunung Butak Tingginya adalah  2.868 mdpl.",
        "Gunung Panderman di Kota Batu memiliki ketinggian 2.045 meter di atas permukaan laut (mdpl)",
        "Gunung Semeru merupakan gunung tertinggi di Jawa Timur. Puncak Mahameru berada di ketinggian 3.676 mdpl.",
        "Gunung Welirang setinggi 3.156 mdpl dan di puncaknya terdapat kawah yang mengandung belerang. ")

    private val gambarGunung = intArrayOf(
        R.drawable.anjasmoro,
        R.drawable.arjuno,
        R.drawable.butak,
        R.drawable.panderman,
        R.drawable.semeru,
        R.drawable.welirang)

    val listData: ArrayList<Gunung>
        get() {
            val list = arrayListOf<Gunung>()
            for (position in namaGunung.indices) {
                val gunung = Gunung()
                gunung.name = namaGunung[position]
                gunung.detail = detailGunung[position]
                gunung.photo = gambarGunung[position]
                list.add(gunung)
            }
            return list
        }
}