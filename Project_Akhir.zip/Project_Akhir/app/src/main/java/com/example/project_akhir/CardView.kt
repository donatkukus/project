package com.example.project_akhir
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class CardView : AppCompatActivity(){
    lateinit var reservasiBtn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.item_cardview)
        reservasiBtn = findViewById(R.id.btn_reserv)
        reservasiBtn.setOnClickListener(){

        }

    }
}