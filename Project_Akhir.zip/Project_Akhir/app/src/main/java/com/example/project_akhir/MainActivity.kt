package com.example.project_akhir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    lateinit var name_list: ArrayList<String>
    lateinit var email_list: ArrayList<String>
    lateinit var password_list: ArrayList<String>
    private lateinit var buat_akun: Button
    private lateinit var btnLogin: Button
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        buat_akun = findViewById(R.id.btn_buatAkun)
        btnLogin = findViewById(R.id.btn_masuk)
        buat_akun.setOnClickListener(){
            intent =  Intent(this,register::class.java)
            startActivity(intent)
        }

        btnLogin.setOnClickListener(){
            intent = getIntent()
            email_list = intent.getStringArrayListExtra("email") as ArrayList<String>
            password_list = intent.getStringArrayListExtra("password") as ArrayList<String>
            var email = findViewById<EditText>(R.id.masuk_email).text.toString()
            var pass = findViewById<EditText>(R.id.masuk_pass).text.toString()
            if(email_list.contains(email)&&password_list.contains(pass)){
                startActivity(Intent(this,search_main::class.java))
            }

        }
    }


}