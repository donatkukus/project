package com.example.project_akhir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class register : AppCompatActivity() {

    lateinit var password_list: ArrayList<String>
    lateinit var name_list: ArrayList<String>
    lateinit var email_list: ArrayList<String>
    lateinit var nama : EditText
    lateinit var email : EditText
    lateinit var password : EditText
    lateinit var btn_regis : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        nama = findViewById(R.id.isi_nama)
        email = findViewById(R.id.isi_email)
        password = findViewById(R.id.isi_katasandi)
        btn_regis = findViewById(R.id.simpan_akun)
        name_list = ArrayList<String>()
        email_list = ArrayList<String>()
        password_list = ArrayList<String>()


        btn_regis.setOnClickListener (){
            intent = Intent(this,MainActivity::class.java)
            name_list.add(nama.text.toString())
            password_list.add(password.text.toString())
            email_list.add(email.text.toString())
            intent.putExtra("username",name_list)
            intent.putExtra("password",password_list)
            intent.putExtra("email",email_list)
            startActivity(intent)
        }
    }


}