package com.example.project_akhir

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class password_main : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password_main)
    }
}